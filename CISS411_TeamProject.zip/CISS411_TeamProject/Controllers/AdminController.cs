﻿using Microsoft.AspNetCore.Mvc;

namespace CISS411_TeamProject.Controllers
{
    public class AdminController: Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
