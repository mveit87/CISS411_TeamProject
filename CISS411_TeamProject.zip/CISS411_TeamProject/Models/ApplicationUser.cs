﻿using Microsoft.AspNetCore.Identity;

namespace CISS411_TeamProject.Models
{
    public class ApplicationUser: IdentityUser
    {
    }
}
