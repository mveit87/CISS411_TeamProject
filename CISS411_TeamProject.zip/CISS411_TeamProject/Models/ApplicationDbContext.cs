﻿using CISS411_TeamProject.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

using Microsoft.EntityFrameworkCore;



namespace CISS411_TeamProject.Models

{

    public class ApplicationDbContext :

            IdentityDbContext<ApplicationUser>

    {

        public ApplicationDbContext(DbContextOptions

            <ApplicationDbContext> options)

            : base(options)

        {

        }

    }

}