﻿using System.ComponentModel.DataAnnotations;
namespace CISS411_TeamProject.ViewModels
{
    public class AccountLoginViewModel
    {
        [Required, EmailAddress]

        public string Email { get; set; }

        [Required, DataType(DataType.Password)]

        public string Password { get; set; }
    }
}
